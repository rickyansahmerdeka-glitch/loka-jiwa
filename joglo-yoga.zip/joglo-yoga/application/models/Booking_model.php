<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking_model extends CI_Model {

    // --- BAGIAN PUBLIK (CUSTOMER) ---

    // Ambil semua jadwal kelas dari tabel schedules
    public function get_all_schedules() {
        $this->db->order_by('hari_tanggal', 'ASC');
        return $this->db->get('schedules')->result();
    }

    // Simpan data customer baru
    public function insert_customer($data) {
        $this->db->insert('customers', $data);
        return $this->db->insert_id();
    }

    // Simpan data booking
    public function insert_booking($data) {
        return $this->db->insert('bookings', $data);
    }

    // Update jumlah kursi terisi (+1)
    public function update_slots($schedule_id) {
        $this->db->set('terisi', 'terisi + 1', FALSE);
        $this->db->where('id', $schedule_id);
        $this->db->update('schedules');
    }

    // --- BAGIAN ADMIN ---

    // Cek Login Admin
    public function get_admin($username, $password) {
        $this->db->where('username', $username);
        $this->db->where('password', md5($password));
        return $this->db->get('admins')->row();
    }

    // Ambil jadwal berdasarkan ID untuk diedit
    public function get_schedule_by_id($id) {
        return $this->db->get_where('schedules', ['id' => $id])->row();
    }

    // Tambah jadwal baru
    public function insert_schedule($data) {
        return $this->db->insert('schedules', $data);
    }

    // Update jadwal
    public function update_schedule($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('schedules', $data);
    }

    // Hapus jadwal
    public function delete_schedule($id) {
        $this->db->where('id', $id);
        return $this->db->delete('schedules');
    }

    // Ambil semua data peserta booking (tanpa metode_pembayaran agar cocok dengan struktur tabel)
    public function get_all_bookings() {
        $this->db->select('
            bookings.id as booking_id, 
            customers.nama, 
            customers.email, 
            customers.telepon, 
            schedules.nama_kelas, 
            schedules.hari_tanggal, 
            schedules.id as schedule_id, 
            bookings.tanggal_booking,
            bookings.bukti_pembayaran
        ');
        $this->db->from('bookings');
        $this->db->join('customers', 'customers.id = bookings.customer_id');
        $this->db->join('schedules', 'schedules.id = bookings.schedule_id');
        $this->db->order_by('bookings.id', 'DESC');
        return $this->db->get()->result();
    }

    // Update data peserta/booking berdasarkan ID booking
    public function update_booking($booking_id, $data) {
        // Ambil customer_id terkait dari tabel bookings terlebih dahulu
        $this->db->select('customer_id');
        $this->db->where('id', $booking_id);
        $booking = $this->db->get('bookings')->row();

        if ($booking) {
            // Update data di tabel customers (nama, email, telepon)
            $this->db->where('id', $booking->customer_id);
            return $this->db->update('customers', $data);
        }
        return FALSE;
    }

    // Batalkan/Hapus booking peserta
    public function delete_booking($booking_id, $schedule_id = NULL) {
        // Kurangi jumlah terisi jika schedule_id ada dan kapasitas terisi > 0
        if (!empty($schedule_id)) {
            $this->db->set('terisi', 'GREATEST(terisi - 1, 0)', FALSE);
            $this->db->where('id', $schedule_id);
            $this->db->update('schedules');
        }

        // Hapus data booking berdasarkan booking_id
        $this->db->where('id', $booking_id);
        return $this->db->delete('bookings');
    }
}