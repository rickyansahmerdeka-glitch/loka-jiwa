<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>LOKA JIWA — Yoga & Pilates Studio</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">

  <style>
    :root {
      --cream: #f4f0e7;
      --paper: #fbf9f4;
      --brown: #4c3b2e;
      --deep: #2f3b32;
      --sage: #788575;
      --line: #d8d0c2;
      --muted: #81776b;
      --danger: #a84b38;
      --danger-bg: #fcece9;
      --wa-green: #25D366;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      font-family: "Montserrat", sans-serif;
      color: var(--brown);
      background: var(--paper);
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    button,
    input,
    select {
      font-family: inherit;
    }

    /* HERO - Nuansa Klasik Rumah Joglo Jawa Coklat Kayu Hangat & Wanita Yoga */
    .hero {
      min-height: 100vh;
      position: relative;
      display: flex;
      align-items: center;
      overflow: hidden;
      background:
        linear-gradient(
          90deg,
          rgba(40, 26, 17, 0.88) 0%,
          rgba(60, 42, 28, 0.70) 50%,
          rgba(30, 20, 12, 0.45) 100%
        ),
        url("https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=2200&q=85")
        center / cover;
    }

    .hero::after {
      content: "";
      position: absolute;
      inset: 0;
      background:
        linear-gradient(
          0deg,
          rgba(38, 25, 16, 0.75),
          transparent 50%
        );
    }

    /* NAVBAR */
    .nav {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      z-index: 5;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 28px 6%;
      color: white;
    }

    .logo {
      font-family: "Cormorant Garamond", serif;
      font-size: 34px;
      letter-spacing: 4px;
    }

    .navlinks {
      display: flex;
      align-items: center;
      gap: 35px;
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .navlinks a {
      opacity: 0.9;
      transition: 0.3s;
    }

    .navlinks a:hover {
      opacity: 0.5;
    }

    .admin-btn {
      border: 1px solid rgba(255, 255, 255, 0.4);
      padding: 8px 16px;
      border-radius: 20px;
    }

    .admin-btn:hover {
      background: rgba(255, 255, 255, 0.2);
      border-color: white;
      opacity: 1 !important;
    }

    /* HERO CONTENT */
    .hero-content {
      position: relative;
      z-index: 2;
      color: white;
      max-width: 760px;
      margin-left: 9%;
      padding-top: 55px;
    }

    .eyebrow {
      font-size: 11px;
      letter-spacing: 4px;
      text-transform: uppercase;
      margin-bottom: 20px;
      color: #dfc8b4;
    }

    .hero h1 {
      font-family: "Cormorant Garamond", serif;
      font-size: clamp(65px, 9vw, 120px);
      line-height: 0.82;
      font-weight: 500;
      margin-bottom: 30px;
      color: #f8f3eb;
    }

    .hero p {
      max-width: 500px;
      font-size: 14px;
      line-height: 1.9;
      color: #ded5c9;
    }

    .btn {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      padding: 15px 27px;
      margin-top: 30px;
      border: 1px solid rgba(255,255,255,0.65);
      color: white;
      text-transform: uppercase;
      letter-spacing: 2px;
      font-size: 10px;
      transition: 0.3s;
    }

    .btn:hover {
      background: white;
      color: var(--brown);
    }

    /* ABOUT */
    .section {
      padding: 100px 8%;
    }

    .intro {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 80px;
      align-items: center;
    }

    .kicker {
      font-size: 10px;
      letter-spacing: 4px;
      text-transform: uppercase;
      color: var(--sage);
      margin-bottom: 18px;
    }

    h2 {
      font-family: "Cormorant Garamond", serif;
      font-size: 60px;
      font-weight: 500;
      line-height: 0.95;
    }

    .intro p {
      margin-top: 25px;
      max-width: 540px;
      font-size: 13px;
      line-height: 2;
      color: var(--muted);
    }

    .quote {
      margin-top: 35px;
      padding-left: 20px;
      border-left: 2px solid var(--brown);
      font-family: "Cormorant Garamond", serif;
      font-size: 25px;
      line-height: 1.3;
      color: var(--brown);
    }

    .joglo {
      height: 540px;
      background:
        url("https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=1300&q=85")
        center / cover;
      border-radius: 4px;
    }

    /* BOOKING */
    .booking-wrap {
      background: var(--cream);
      padding: 110px 8%;
    }

    .booking-head {
      text-align: center;
      margin-bottom: 55px;
    }

    .booking-head p {
      max-width: 500px;
      margin: 18px auto 0;
      font-size: 13px;
      line-height: 1.8;
      color: var(--muted);
    }

    .booking {
      max-width: 1080px;
      margin: auto;
      display: grid;
      grid-template-columns: 1.05fr 0.95fr;
      background: var(--paper);
      box-shadow: 0 25px 70px rgba(66,53,40,0.10);
    }

    .form-side {
      padding: 48px;
    }

    .summary-side {
      padding: 48px;
      background: var(--deep);
      color: #f7f3ea;
      position: relative;
      overflow: hidden;
    }

    .summary-side::before {
      content: "";
      position: absolute;
      width: 260px;
      height: 260px;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 50%;
      right: -100px;
      top: -100px;
    }

    .field {
      margin-bottom: 25px;
    }

    label {
      display: block;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 9px;
      color: var(--muted);
    }

    input,
    select {
      width: 100%;
      padding: 15px 0;
      border: none;
      border-bottom: 1px solid var(--line);
      outline: none;
      background: transparent;
      color: var(--brown);
    }

    input:focus,
    select:focus {
      border-color: var(--sage);
    }

    /* PAYMENT & FILE UPLOAD */
    .payment-box {
      display: none;
      background: var(--cream);
      border: 1px solid var(--line);
      padding: 20px;
      margin-top: 15px;
      border-radius: 2px;
      text-align: center;
      animation: fadeIn 0.4s ease-in-out;
    }

    .payment-box p {
      font-size: 11px;
      color: var(--brown);
      line-height: 1.6;
    }

    .payment-box .rekening-num {
      font-size: 16px;
      font-weight: 600;
      letter-spacing: 2px;
      color: var(--deep);
      margin: 8px 0 2px 0;
    }

    .payment-box img.qris-img {
      max-width: 170px;
      width: 100%;
      border: 1px solid var(--line);
      margin: 10px 0;
      background: #fff;
      padding: 6px;
    }

    .file-input-wrapper {
      position: relative;
      margin-top: 8px;
    }

    input[type="file"] {
      border-bottom: none;
      padding: 10px 0;
      font-size: 11px;
      color: var(--muted);
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-5px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .submit {
      width: 100%;
      padding: 17px;
      border: none;
      background: var(--brown);
      color: white;
      text-transform: uppercase;
      letter-spacing: 2px;
      font-size: 10px;
      cursor: pointer;
      margin-top: 15px;
      transition: 0.3s;
    }

    .submit:hover {
      background: var(--deep);
    }

    .summary-title {
      position: relative;
      z-index: 1;
      font-family: "Cormorant Garamond", serif;
      font-size: 43px;
      margin-bottom: 35px;
    }

    .summary-line {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      padding: 16px 0;
      border-bottom: 1px solid rgba(255,255,255,0.14);
      font-size: 12px;
    }

    .summary-line span:first-child {
      opacity: 0.55;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      font-size: 9px;
    }

    .note {
      margin-top: 35px;
      font-size: 11px;
      line-height: 1.8;
      opacity: 0.65;
    }

    /* KARTU BUKTI PENDAFTARAN & TOMBOL DOWNLOAD / CETAK BUKTI */
    .receipt-card {
      max-width: 1080px;
      margin: 0 auto 40px auto;
      background: #ffffff;
      border: 2px dashed var(--brown);
      padding: 35px 45px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.05);
      position: relative;
    }

    .receipt-actions {
      display: flex;
      gap: 15px;
      margin-top: 25px;
      flex-wrap: wrap;
    }

    .btn-download-pdf {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: var(--brown);
      color: white;
      padding: 12px 24px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 1px;
      text-transform: uppercase;
      border: none;
      cursor: pointer;
      border-radius: 4px;
      transition: 0.3s;
    }

    .btn-download-pdf:hover {
      background: var(--deep);
    }

    .btn-wa-notif {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: var(--wa-green);
      color: white;
      padding: 12px 24px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 1px;
      text-transform: uppercase;
      border-radius: 4px;
      transition: 0.3s;
    }

    .btn-wa-notif:hover {
      background: #1eb857;
      color: white;
    }

    .alert-error {
      max-width: 1080px;
      margin: 0 auto 30px auto;
      background: var(--danger-bg);
      border: 1px solid var(--danger);
      color: var(--danger);
      padding: 15px 20px;
      font-size: 12px;
    }

    .receipt-title {
      font-family: "Cormorant Garamond", serif;
      font-size: 32px;
      color: var(--brown);
      margin-bottom: 5px;
    }

    .receipt-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-top: 20px;
      font-size: 12px;
      border-top: 1px solid var(--line);
      padding-top: 20px;
    }

    .receipt-item strong {
      display: block;
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--muted);
      margin-bottom: 4px;
    }

    /* CLASSES & STATUS KUOTA */
    .classes {
      background: #eee9df;
    }

    .class-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 55px;
    }

    .card {
      background: var(--paper);
      padding: 35px;
      min-height: 320px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 1px solid rgba(76,59,46,0.08);
      transition: 0.3s;
    }

    .card:hover {
      transform: translateY(-6px);
      box-shadow: 0 20px 40px rgba(76,59,46,0.08);
    }

    .card h3 {
      font-family: "Cormorant Garamond", serif;
      font-size: 34px;
      font-weight: 500;
    }

    .card p {
      font-size: 11px;
      line-height: 1.8;
      color: var(--muted);
      margin-top: 12px;
    }

    .status-badge {
      display: inline-block;
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      padding: 5px 10px;
      margin-top: 15px;
      font-weight: 600;
    }

    .status-available {
      background: #ebf2ed;
      color: var(--deep);
      border: 1px solid var(--sage);
    }

    .status-full {
      background: var(--danger-bg);
      color: var(--danger);
      border: 1px solid var(--danger);
    }

    .card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 25px;
      padding-top: 15px;
      border-top: 1px solid var(--line);
    }

    .price {
      font-size: 12px;
      letter-spacing: 1px;
    }

    .tag {
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: var(--sage);
      margin-bottom: 10px;
    }

    /* FOOTER */
    footer {
      padding: 45px 8%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      letter-spacing: 1px;
      color: var(--muted);
    }

    footer strong {
      font-family: "Cormorant Garamond", serif;
      font-size: 27px;
      font-weight: 500;
      color: var(--brown);
    }

    /* FORMAT CETAK BUKTI PENDAFTARAN (PRINT/PDF) */
    @media print {
      body * {
        visibility: hidden;
      }
      .receipt-card, .receipt-card * {
        visibility: visible;
      }
      .receipt-card {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        border: 2px dashed #000;
        box-shadow: none;
      }
      .receipt-actions {
        display: none !important;
      }
    }

    /* MOBILE RESPONSIVE */
    @media(max-width: 800px) {
      .navlinks {
        display: none;
      }

      .hero-content {
        margin-left: 7%;
        margin-right: 7%;
      }

      .intro,
      .booking {
        grid-template-columns: 1fr;
      }

      .joglo {
        height: 380px;
      }

      .section,
      .booking-wrap {
        padding: 75px 6%;
      }

      .class-grid {
        grid-template-columns: 1fr;
      }

      h2 {
        font-size: 48px;
      }

      .form-side,
      .summary-side {
        padding: 35px 27px;
      }

      footer {
        flex-direction: column;
        gap: 15px;
        text-align: center;
      }
    }
  </style>
</head>

<body>

<!-- HERO -->
<header class="hero" id="home">
  <nav class="nav">
    <a href="#home" class="logo">LOKA JIWA</a>
    <div class="navlinks">
      <a href="#about">Tentang</a>
      <a href="#classes">Kelas</a>
      <a href="#booking">Booking</a>
      <a href="<?= site_url('auth'); ?>" class="admin-btn">Login Admin &rarr;</a>
    </div>
  </nav>

  <div class="hero-content">
    <div class="eyebrow">Rumah Joglo Jawa • Yoga Studio</div>
    <h1>Ruang untuk<br>kembali.</h1>
    <p>
      Kehangatan arsitektur kayu khas Joglo Jawa, dipadukan dengan keselarasan gerak dan napas.
      Kembali hadir, melangkah pelan, dan temukan ketenangan jiwa.
    </p>
    <a href="#booking" class="btn">Reservasi Kelas</a>
  </div>
</header>

<!-- ABOUT -->
<section class="section" id="about">
  <div class="intro">
    <div>
      <div class="kicker">The Wooden Sanctuary</div>
      <h2>Yoga yang terasa seperti pulang.</h2>
      <p>
        LOKA JIWA dirancang sebagai ruang kecil untuk memperlambat langkah.
        Struktur kayu tumpang sari, udara terbuka, dan ketenangan alami Jawa menyatu dalam suasana
        rumah joglo yang bernuansa coklat hangat dan penuh kedamaian.
      </p>
      <div class="quote">
        “Pelan bukan berarti berhenti. Pelan adalah cara untuk benar-benar hadir.”
      </div>
    </div>
    <div class="joglo"></div>
  </div>
</section>

<!-- BOOKING -->
<section class="booking-wrap" id="booking">
  <div class="booking-head">
    <div class="kicker">Reservation</div>
    <h2>Pesan tempatmu.</h2>
    <p>
      Pilih kelas, tentukan waktumu, lalu datang tanpa perlu terburu-buru.
    </p>
  </div>

  <!-- PESAN ERROR -->
  <?php if($this->session->flashdata('status') === 'gagal'): ?>
    <div class="alert-error">
      <strong>⚠ Reservasi Gagal:</strong> <?= $this->session->flashdata('error_message'); ?>
    </div>
  <?php endif; ?>

  <!-- HASIL PENDAFTARAN & BUKTI / STRUK PENDAFTARAN -->
  <?php if($this->session->flashdata('pendaftaran_baru')): ?>
    <?php 
      $p = $this->session->flashdata('pendaftaran_baru'); 
      
      // Sanitasi nomor HP untuk WhatsApp
      $phone_wa = preg_replace('/[^0-9]/', '', $p['telepon']);
      if (substr($phone_wa, 0, 1) === '0') {
          $phone_wa = '62' . substr($phone_wa, 1);
      }

      $wa_text  = "Halo *" . $p['nama'] . "*,\n\n";
      $wa_text .= "Terima kasih! Bukti reservasi Anda di *LOKA JIWA* telah berhasil dicatat:\n\n";
      $wa_text .= "🧘 *Kelas:* " . $p['nama_kelas'] . "\n";
      $wa_text .= "📅 *Jadwal:* " . date('d M Y, H:i', strtotime($p['hari_tanggal'])) . " WIB\n";
      $wa_text .= "📍 *Lokasi:* Studio Rumah Joglo - Loka Jiwa\n\n";
      $wa_text .= "Mohon simpan bukti ini dan hadir 10–15 menit sebelum kelas dimulai.";
      
      $wa_link  = "https://wa.me/" . $phone_wa . "?text=" . urlencode($wa_text);
    ?>
    
    <div class="receipt-card" id="printableReceipt">
      <div class="receipt-title">✦ Bukti Reservasi Pendaftaran</div>
      <p style="font-size: 11px; color: var(--muted);">LOKA JIWA STUDIO — Rumah Joglo Jawa</p>
      
      <div class="receipt-grid">
        <div class="receipt-item">
          <strong>Nama Peserta</strong>
          <span><?= htmlspecialchars($p['nama']); ?></span>
        </div>
        <div class="receipt-item">
          <strong>Kelas Yoga / Pilates</strong>
          <span><?= htmlspecialchars($p['nama_kelas']); ?></span>
        </div>
        <div class="receipt-item">
          <strong>Jadwal & Waktu</strong>
          <span><?= date('d M Y, H:i', strtotime($p['hari_tanggal'])); ?> WIB</span>
        </div>
        <div class="receipt-item">
          <strong>No. WhatsApp / Kontak</strong>
          <span><?= htmlspecialchars($p['telepon']); ?></span>
        </div>
        <?php if(!empty($p['metode_pembayaran'])): ?>
        <div class="receipt-item">
          <strong>Metode Pembayaran</strong>
          <span><?= strtoupper(htmlspecialchars($p['metode_pembayaran'])); ?></span>
        </div>
        <?php endif; ?>
        <div class="receipt-item">
          <strong>Status Reservasi</strong>
          <span style="color: var(--sage); font-weight: 600;">● Terkonfirmasi Sistem</span>
        </div>
      </div>

      <!-- AKSI: DOWNLOAD / CETAK BUKTI & WA -->
      <div class="receipt-actions">
        <button onclick="window.print()" class="btn-download-pdf">
          📄 Download / Cetak Bukti PDF
        </button>
        <a href="<?= $wa_link; ?>" target="_blank" class="btn-wa-notif">
          📱 Kirim ke WhatsApp
        </a>
      </div>
    </div>
  <?php endif; ?>

  <div class="booking">
    <!-- FORM -->
    <div class="form-side">
      <form action="<?= site_url('yoga/proses_booking'); ?>" method="post" enctype="multipart/form-data">
        
        <div class="field">
          <label for="name">Nama Lengkap</label>
          <input id="name" name="nama" type="text" placeholder="Nama lengkap Anda" required autocomplete="off">
        </div>

        <div class="field">
          <label for="email">Alamat Email</label>
          <input id="email" name="email" type="email" placeholder="email@domain.com" required autocomplete="off">
        </div>

        <div class="field">
          <label for="phone">No. WhatsApp</label>
          <input id="phone" name="telepon" type="tel" placeholder="08xxxxxxxxxx" required autocomplete="off">
        </div>

        <div class="field">
          <label for="schedule_id">Pilih Sesi Kelas</label>
          <select id="schedule_id" name="schedule_id" required>
            <option value="">Pilih Sesi & Waktu</option>
            <?php foreach($schedules as $s): ?>
              <?php 
                $sisa_kursi = $s->kapasitas - $s->terisi;
                $is_full = ($sisa_kursi <= 0);
              ?>
              <option value="<?= $s->id; ?>" <?= $is_full ? 'disabled' : ''; ?> 
                      data-kelas="<?= htmlspecialchars($s->nama_kelas); ?>" 
                      data-tanggal="<?= date('d M Y, H:i', strtotime($s->hari_tanggal)); ?> WIB">
                <?= htmlspecialchars($s->nama_kelas); ?> — <?= date('d M Y, H:i', strtotime($s->hari_tanggal)); ?> WIB 
                <?= $is_full ? '(PENUH)' : '('.$sisa_kursi.' tempat tersisa)'; ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- FITUR PILIHAN PEMBAYARAN -->
        <div class="field">
          <label for="metode_pembayaran">Metode Pembayaran</label>
          <select id="metode_pembayaran" name="metode_pembayaran" onchange="togglePayment()" required>
            <option value="">Pilih Metode Pembayaran</option>
            <option value="qris">QRIS (All Payment)</option>
            <option value="transfer">Transfer Bank (BCA)</option>
          </select>

          <!-- BOX DETAIL QRIS -->
          <div id="box_qris" class="payment-box">
            <p>Silakan scan QRIS di bawah ini untuk menyelesaikan pembayaran:</p>
            <img src="<?= base_url('assets/images/qris.png'); ?>" alt="QRIS Loka Jiwa" class="qris-img" onerror="this.src='https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=LOKA_JIWA_STUDIO'">
            <p style="font-weight: 600; color: var(--deep);">A/N LOKA JIWA STUDIO</p>
          </div>

          <!-- BOX DETAIL TRANSFER BANK -->
          <div id="box_transfer" class="payment-box">
            <p>Transfer tepat nominal ke rekening berikut:</p>
            <div class="rekening-num">8415-8890-12</div>
            <p><strong>Bank BCA</strong> a/n <strong>LOKA JIWA STUDIO</strong></p>
          </div>
        </div>

        <!-- UPLOAD BUKTI PEMBAYARAN -->
        <div class="field" id="upload_bukti_group" style="display: none;">
          <label for="bukti_pembayaran">Upload Bukti Pembayaran</label>
          <div class="file-input-wrapper">
            <input type="file" id="bukti_pembayaran" name="bukti_pembayaran" accept="image/png, image/jpeg, image/jpg, image/webp">
          </div>
        </div>

        <button type="submit" class="submit">Konfirmasi Booking</button>
      </form>
    </div>

    <!-- SUMMARY -->
    <div class="summary-side">
      <div class="summary-title">Your quiet<br>moment.</div>

      <div class="summary-line">
        <span>Studio</span>
        <span>LOKA JIWA</span>
      </div>

      <div class="summary-line">
        <span>Venue</span>
        <span>Rumah Joglo Jawa</span>
      </div>

      <div class="summary-line">
        <span>Class</span>
        <span id="previewClass">—</span>
      </div>

      <div class="summary-line">
        <span>Date & Time</span>
        <span id="previewDate">—</span>
      </div>

      <div class="note">
        Setiap peserta akan mendapatkan ruang yang tenang dan matras yoga standar studio.<br><br>
        Mohon hadir 10–15 menit sebelum latihan dimulai.
      </div>
    </div>
  </div>
</section>

<!-- CLASSES -->
<section class="section classes" id="classes">
  <div class="kicker">Jadwal & Kuota Kelas</div>
  <h2>Move gently.</h2>

  <div class="class-grid">
    <?php foreach($schedules as $index => $s): ?>
      <?php 
        $sisa = $s->kapasitas - $s->terisi; 
        $nomor = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
        // Mengambil langsung dari kolom 'instruktur' teks bebas
        $instruktur = !empty($s->instruktur) ? $s->instruktur : '-';
      ?>
      <article class="card">
        <div>
          <div class="tag"><?= $nomor; ?> · Sesi Studio</div>
          <h3><?= htmlspecialchars($s->nama_kelas); ?></h3>
          <p>
            Instruktur: <strong><?= htmlspecialchars($instruktur); ?></strong><br>
            Jadwal: <?= date('d M Y, H:i', strtotime($s->hari_tanggal)); ?> WIB
          </p>

          <?php if($sisa > 0): ?>
            <div class="status-badge status-available">
              ● Tersedia (Sisa <?= $sisa; ?> tempat)
            </div>
          <?php else: ?>
            <div class="status-badge status-full">
              ● Sesi Penuh
            </div>
          <?php endif; ?>
        </div>

        <div class="card-footer">
          <div class="price">
            Kapasitas: <?= $s->terisi; ?>/<?= $s->kapasitas; ?>
          </div>
          <?php if($sisa > 0): ?>
            <a href="#booking" style="font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: var(--sage); font-weight: 600;">Pesan &rarr;</a>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <strong>LOKA JIWA</strong>
  <span>Yoga & Pilates · Rumah Joglo Jawa · 2026</span>
</footer>

<!-- JAVASCRIPT -->
<script>
  const scheduleSelect = document.getElementById("schedule_id");
  const previewClass = document.getElementById("previewClass");
  const previewDate = document.getElementById("previewDate");

  scheduleSelect.addEventListener("change", function() {
    const selectedOption = scheduleSelect.options[scheduleSelect.selectedIndex];
    
    if (scheduleSelect.value === "") {
      previewClass.textContent = "—";
      previewDate.textContent = "—";
    } else {
      previewClass.textContent = selectedOption.getAttribute("data-kelas") || "—";
      previewDate.textContent = selectedOption.getAttribute("data-tanggal") || "—";
    }
  });

  function togglePayment() {
    const method = document.getElementById("metode_pembayaran").value;
    const boxQris = document.getElementById("box_qris");
    const boxTransfer = document.getElementById("box_transfer");
    const uploadGroup = document.getElementById("upload_bukti_group");
    const fileInput = document.getElementById("bukti_pembayaran");

    boxQris.style.display = "none";
    boxTransfer.style.display = "none";

    if (method === "qris" || method === "transfer") {
      if (method === "qris") boxQris.style.display = "block";
      if (method === "transfer") boxTransfer.style.display = "block";
      
      uploadGroup.style.display = "block";
      fileInput.required = true;
    } else {
      uploadGroup.style.display = "none";
      fileInput.required = false;
    }
  }
</script>

</body>
</html>