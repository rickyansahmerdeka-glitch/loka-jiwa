<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Jadwal - Admin</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #F4EFEA; color: #3D2314; padding: 40px; }
        .box { background: #fff; max-width: 500px; margin: 0 auto; padding: 25px; border-radius: 6px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        input { padding: 8px; margin: 5px 0 15px 0; width: 100%; box-sizing: border-box; }
        button { background: #A86532; color: #fff; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="box">
        <h3>Edit Jadwal Kelas</h3>
        <form action="<?= site_url('admin/update_jadwal/'.$schedule->id); ?>" method="post">
            <label>Nama Kelas:</label>
            <input type="text" name="nama_kelas" value="<?= $schedule->nama_kelas; ?>" required>
            
            <label>Hari & Jam (Format: YYYY-MM-DD HH:MM:SS):</label>
            <input type="text" name="hari_tanggal" value="<?= $schedule->hari_tanggal; ?>" required>
            
            <label>Kapasitas Kursi:</label>
            <input type="number" name="kapasitas" value="<?= $schedule->kapasitas; ?>" required>
            
            <button type="submit">Perbarui Jadwal</button>
            <a href="<?= site_url('admin'); ?>" style="margin-left: 10px; color: #3D2314; text-decoration: none;">Kembali</a>
        </form>
    </div>
</body>
</html>