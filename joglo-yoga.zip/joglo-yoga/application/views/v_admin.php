<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Pengelola — LOKA JIWA</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">

  <style>
    :root {
      --cream: #f4f0e7;
      --paper: #fbf9f4;
      --brown: #4c3b2e;
      --deep: #2f3b32;
      --sage: #788575;
      --line: #e3dcd1;
      --muted: #81776b;
      --danger: #a84b38;
      --danger-bg: #fcece9;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: "Montserrat", sans-serif;
      color: var(--brown);
      background: var(--paper);
      padding-bottom: 80px;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    /* HEADER / NAVBAR */
    .admin-nav {
      background: var(--paper);
      border-bottom: 1px solid var(--line);
      padding: 20px 5%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .brand-title {
      font-family: "Cormorant Garamond", serif;
      font-size: 26px;
      letter-spacing: 2px;
      font-weight: 600;
    }

    .nav-actions {
      display: flex;
      gap: 12px;
    }

    .btn-nav {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      padding: 9px 18px;
      border-radius: 4px;
      transition: 0.3s;
    }

    .btn-site {
      border: 1px solid var(--sage);
      color: var(--deep);
    }

    .btn-site:hover {
      background: var(--sage);
      color: white;
    }

    .btn-logout {
      background: var(--danger);
      color: white;
    }

    .btn-logout:hover {
      opacity: 0.85;
    }

    /* MAIN CONTAINER */
    .container {
      max-width: 1200px;
      margin: 40px auto 0;
      padding: 0 4%;
    }

    /* DASHBOARD GRID */
    .dashboard-grid {
      display: grid;
      grid-template-columns: 360px 1fr;
      gap: 35px;
      align-items: start;
    }

    /* CARDS & PANELS */
    .panel-card {
      background: white;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 30px;
      box-shadow: 0 10px 30px rgba(76,59,46,0.03);
      margin-bottom: 35px;
    }

    .panel-header {
      margin-bottom: 25px;
    }

    .panel-header-flex {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      flex-wrap: wrap;
      gap: 15px;
    }

    .panel-header h2 {
      font-family: "Cormorant Garamond", serif;
      font-size: 28px;
      font-weight: 600;
      color: var(--brown);
    }

    .panel-header p {
      font-size: 11px;
      color: var(--muted);
      margin-top: 4px;
    }

    /* SEARCH & TOOLBAR */
    .toolbar-container {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }

    .search-input {
      flex: 1;
      min-width: 200px;
      padding: 10px 14px;
      border: 1px solid var(--line);
      border-radius: 4px;
      background: var(--paper);
      font-size: 12px;
    }

    .btn-export {
      background: var(--sage);
      color: white;
      border: none;
      padding: 10px 16px;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-radius: 4px;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn-export:hover {
      background: var(--deep);
    }

    /* FORM STYLING */
    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--muted);
      margin-bottom: 8px;
      font-weight: 600;
    }

    input, select {
      width: 100%;
      padding: 12px 14px;
      border: 1px solid var(--line);
      border-radius: 4px;
      background: var(--paper);
      font-family: inherit;
      font-size: 12px;
      color: var(--brown);
      outline: none;
      transition: 0.3s;
    }

    input:focus, select:focus {
      border-color: var(--sage);
      background: white;
    }

    .btn-submit {
      width: 100%;
      padding: 14px;
      background: var(--brown);
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 2px;
      cursor: pointer;
      transition: 0.3s;
      margin-top: 10px;
    }

    .btn-submit:hover {
      background: var(--deep);
    }

    /* TABLES STYLING */
    .table-responsive {
      overflow-x: auto;
      width: 100%;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 12px;
    }

    th {
      background: var(--cream);
      color: var(--brown);
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      padding: 14px 16px;
      border-bottom: 1px solid var(--line);
      white-space: nowrap;
    }

    td {
      padding: 14px 16px;
      border-bottom: 1px solid var(--line);
      color: var(--brown);
      vertical-align: middle;
    }

    tr:hover td {
      background: rgba(244, 240, 231, 0.4);
    }

    /* STYLING BUKTI PEMBAYARAN */
    .img-bukti-thumb {
      width: 50px;
      height: 50px;
      object-fit: cover;
      border-radius: 4px;
      border: 1px solid var(--line);
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .img-bukti-thumb:hover {
      transform: scale(1.08);
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    .text-no-bukti {
      font-size: 10px;
      color: var(--muted);
      font-style: italic;
    }

    /* SUB-GROUP KELAS PESERTA */
    .class-group-card {
      background: var(--paper);
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 20px;
      margin-bottom: 25px;
    }

    .class-group-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 12px;
      margin-bottom: 15px;
      border-bottom: 1px dashed var(--line);
    }

    .class-group-title {
      font-family: "Cormorant Garamond", serif;
      font-size: 22px;
      font-weight: 600;
      color: var(--deep);
    }

    .class-group-subtitle {
      font-size: 11px;
      color: var(--muted);
    }

    /* BADGES & BUTTONS IN TABLE */
    .badge-quota {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 3px;
      font-size: 10px;
      font-weight: 600;
    }

    .badge-available {
      background: #eef4f0;
      color: var(--deep);
    }

    .badge-full {
      background: var(--danger-bg);
      color: var(--danger);
    }

    .action-group {
      display: flex;
      gap: 6px;
    }

    .btn-action {
      display: inline-block;
      padding: 6px 12px;
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-radius: 3px;
      transition: 0.2s;
      cursor: pointer;
      border: none;
    }

    .btn-edit {
      background: #e2ded5;
      color: var(--brown);
    }

    .btn-edit:hover {
      background: var(--line);
    }

    .btn-delete {
      background: var(--danger-bg);
      color: var(--danger);
    }

    .btn-delete:hover {
      background: var(--danger);
      color: white;
    }

    /* MODAL STYLING */
    .modal-overlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(47, 59, 50, 0.5);
      backdrop-filter: blur(3px);
      z-index: 200;
      justify-content: center;
      align-items: center;
    }

    .modal-box {
      background: white;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 30px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 20px 50px rgba(0,0,0,0.15);
    }

    .modal-box-image {
      max-width: 600px;
      text-align: center;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .modal-header h3 {
      font-family: "Cormorant Garamond", serif;
      font-size: 24px;
      color: var(--brown);
    }

    .close-modal {
      background: none;
      border: none;
      font-size: 22px;
      color: var(--muted);
      cursor: pointer;
    }

    .preview-full-img {
      max-width: 100%;
      max-height: 70vh;
      border-radius: 6px;
      border: 1px solid var(--line);
    }

    @media(max-width: 900px) {
      .dashboard-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>

<body>

  <!-- NAVBAR ADMIN -->
  <header class="admin-nav">
    <div class="brand-title">LOKA JIWA — Admin</div>
    <div class="nav-actions">
      <a href="<?= site_url('yoga'); ?>" target="_blank" class="btn-nav btn-site">Lihat Website &rarr;</a>
      <a href="<?= site_url('auth/logout'); ?>" class="btn-nav btn-logout">Keluar (Logout)</a>
    </div>
  </header>

  <div class="container">
    <div class="dashboard-grid">

      <!-- FORM TAMBAH JADWAL (KIRI) -->
      <section class="panel-card">
        <div class="panel-header">
          <h2>Tambah Kelas</h2>
          <p>Buat jadwal sesi latihan baru untuk peserta.</p>
        </div>

        <form action="<?= site_url('admin/simpan_jadwal'); ?>" method="post">
          <div class="form-group">
            <label for="nama_kelas">Jenis Class / Nama Kelas</label>
            <input type="text" id="nama_kelas" name="nama_kelas" placeholder="Contoh: Beginner atau all levels" required>
          </div>

          <!-- ATRIBUT NAME DISESUAIKAN DENGAN CONTROLLER: instructor_id -->
          <div class="field">
           <label for="instruktur">NAMA INSTRUKTUR</label>
           <input type="text" id="instruktur" name="instruktur" placeholder="Contoh: Ananda Dewi" required>
          </div>

          <div class="form-group">
            <label for="hari_tanggal">Hari & Waktu</label>
            <input type="datetime-local" id="hari_tanggal" name="hari_tanggal" required>
          </div>

          <div class="form-group">
            <label for="kapasitas">Kapasitas Maksimal</label>
            <input type="number" id="kapasitas" name="kapasitas" placeholder="5" min="1" required>
          </div>

          <button type="submit" class="btn-submit">Simpan Jadwal</button>
        </form>
      </section>

      <!-- KELOLA JADWAL & PESERTA (KANAN) -->
      <div>

        <!-- KELOLA JADWAL -->
        <section class="panel-card">
          <div class="panel-header">
            <h2>Kelola Jadwal Yoga</h2>
            <p>Daftar sesi kelas yang aktif saat ini.</p>
          </div>

          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nama Kelas</th>
                  <th>Waktu</th>
                  <th>Kapasitas</th>
                  <th>Terisi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!empty($schedules)): ?>
                  <?php foreach($schedules as$s): ?>
                    <?php 
                      $schedule_id = isset($s->id) ?$s->id : (isset($s->id_jadwal) ?$s->id_jadwal : '');
                    ?>
                    <tr>
                      <td>#<?= $schedule_id; ?></td>
                      <td><strong><?= htmlspecialchars($s->nama_kelas); ?></strong></td>
                      <td><?= date('d M Y, H:i', strtotime($s->hari_tanggal)); ?> WIB</td>
                      <td><?= $s->kapasitas; ?> Orang</td>
                      <td>
                        <span class="badge-quota <?= ($s->terisi >=$s->kapasitas) ? 'badge-full' : 'badge-available'; ?>">
                          <?= $s->terisi; ?> / <?=$s->kapasitas; ?>
                        </span>
                      </td>
                      <td>
                        <div class="action-group">
                          <a href="<?= site_url('admin/edit_jadwal/'.$schedule_id); ?>" class="btn-action btn-edit">Edit</a>
                          <a href="<?= site_url('admin/hapus_jadwal/'.$schedule_id); ?>" class="btn-action btn-delete" onclick="return confirm('Yakin ingin menghapus jadwal ini?');">Hapus</a>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="6" style="text-align:center; color: var(--muted);">Belum ada jadwal kelas.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>

        <!-- DAFTAR PESERTA PER SESI KELAS -->
        <section class="panel-card">
          <div class="panel-header panel-header-flex">
            <div>
              <h2>Daftar Peserta Booking</h2>
              <p>Data peserta terpisah berdasarkan kelas dan jadwal masing-masing.</p>
            </div>
          </div>

          <!-- PENCARIAN & EXPORT CSV -->
          <div class="toolbar-container">
            <input type="text" id="searchParticipant" class="search-input" onkeyup="filterParticipants()" placeholder="Cari nama, email, atau telepon peserta...">
            <button type="button" class="btn-export" onclick="exportParticipantsToCSV()">Export Data Peserta (.csv)</button>
          </div>

          <?php if(!empty($schedules)): ?>
            <?php foreach($schedules as$s): ?>
              <?php 
                $sch_id = isset($s->id) ?$s->id : (isset($s->id_jadwal) ?$s->id_jadwal : '');
                
                // Filter peserta yang terdaftar di kelas/sesi ini
                $participants = array_filter($bookings, function($b) use ($sch_id,$s) {
                  if (isset($b->schedule_id)) {
                    return $b->schedule_id ==$sch_id;
                  } elseif (isset($b->id_jadwal)) {
                    return $b->id_jadwal ==$sch_id;
                  } else {
                    return ($b->nama_kelas ==$s->nama_kelas && $b->hari_tanggal ==$s->hari_tanggal);
                  }
                });
              ?>

              <div class="class-group-card participant-card">
                <div class="class-group-header">
                  <div>
                    <div class="class-group-title"><?= htmlspecialchars($s->nama_kelas); ?></div>
                    <div class="class-group-subtitle">
                      🕒 <?= date('d M Y, H:i', strtotime($s->hari_tanggal)); ?> WIB
                    </div>
                  </div>
                  <div>
                    <span class="badge-quota <?= ($s->terisi >=$s->kapasitas) ? 'badge-full' : 'badge-available'; ?>">
                      Terisi: <?= count($participants); ?> / <?=$s->kapasitas; ?> Peserta
                    </span>
                  </div>
                </div>

                <div class="table-responsive">
                  <table class="participant-table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Peserta</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Bukti Bayar</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(!empty($participants)): ?>
                        <?php $no = 1; foreach($participants as$b): ?>
                          <?php 
                            $booking_id = '';
                            if (isset($b->id_booking)) {
                                $booking_id =$b->id_booking;
                            } elseif (isset($b->id_pendaftaran)) {
                                $booking_id =$b->id_pendaftaran;
                            } elseif (isset($b->booking_id)) {
                                $booking_id =$b->booking_id;
                            } elseif (isset($b->id)) {
                                $booking_id =$b->id;
                            }

                            // Menentukan nama field bukti pembayaran
                            $bukti = '';
                            if (!empty($b->bukti_pembayaran)) {
                                $bukti =$b->bukti_pembayaran;
                            } elseif (!empty($b->bukti_bayar)) {
                                $bukti =$b->bukti_bayar;
                            } elseif (!empty($b->bukti)) {
                                $bukti =$b->bukti;
                            }
                          ?>
                          <tr class="participant-row">
                            <td style="width: 40px;"><?= $no++; ?></td>
                            <td class="search-target"><strong><?= htmlspecialchars($b->nama); ?></strong></td>
                            <td class="search-target"><?= htmlspecialchars($b->email); ?></td>
                            <td class="search-target"><?= htmlspecialchars($b->telepon); ?></td>
                            
                            <!-- BUKTI PEMBAYARAN -->
                            <td>
                              <?php if(!empty($bukti)): ?>
                                <?php $img_path = base_url('uploads/bukti/'.$bukti); ?>
                                <img src="<?= $img_path; ?>" 
                                     alt="Bukti Bayar" 
                                     class="img-bukti-thumb" 
                                     onclick="previewBukti('<?= $img_path; ?>', '<?= htmlspecialchars($b->nama, ENT_QUOTES); ?>')">
                              <?php else: ?>
                                <span class="text-no-bukti">Belum Upload</span>
                              <?php endif; ?>
                            </td>

                            <td style="width: 140px;">
                              <div class="action-group">
                                <button type="button" class="btn-action btn-edit" 
                                        onclick="openEditModal('<?= $booking_id; ?>', '<?= htmlspecialchars($b->nama, ENT_QUOTES); ?>', '<?= htmlspecialchars($b->email, ENT_QUOTES); ?>', '<?= htmlspecialchars($b->telepon, ENT_QUOTES); ?>')">
                                  Edit
                                </button>
                                <a href="<?= site_url('admin/hapus_booking/'.$booking_id.'/'.$sch_id); ?>" class="btn-action btn-delete" onclick="return confirm('Hapus data peserta ini?');">
                                  Hapus
                                </a>
                              </div>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="6" style="text-align:center; color: var(--muted); font-style: italic; padding: 20px;">
                            Belum ada peserta yang mendaftar di kelas ini.
                          </td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>

            <?php endforeach; ?>
          <?php else: ?>
            <p style="text-align: center; color: var(--muted); padding: 20px;">Belum ada sesi kelas yang dibuat.</p>
          <?php endif; ?>

        </section>

      </div>

    </div>
  </div>

  <!-- MODAL EDIT PESERTA -->
  <div class="modal-overlay" id="editParticipantModal">
    <div class="modal-box">
      <div class="modal-header">
        <h3>Edit Data Peserta</h3>
        <button type="button" class="close-modal" onclick="closeEditModal()">&times;</button>
      </div>
      <form action="<?= site_url('admin/update_booking'); ?>" method="post">
        <input type="hidden" id="edit_id" name="id">

        <div class="form-group">
          <label for="edit_nama">Nama Lengkap</label>
          <input type="text" id="edit_nama" name="nama" required>
        </div>

        <div class="form-group">
          <label for="edit_email">Alamat Email</label>
          <input type="email" id="edit_email" name="email" required>
        </div>

        <div class="form-group">
          <label for="edit_telepon">No. Telepon / WhatsApp</label>
          <input type="text" id="edit_telepon" name="telepon" required>
        </div>

        <button type="submit" class="btn-submit">Simpan Perubahan</button>
      </form>
    </div>
  </div>

  <!-- MODAL PREVIEW BUKTI PEMBAYARAN -->
  <div class="modal-overlay" id="previewBuktiModal">
    <div class="modal-box modal-box-image">
      <div class="modal-header">
        <h3 id="previewNamaPeserta">Bukti Pembayaran</h3>
        <button type="button" class="close-modal" onclick="closePreviewModal()">&times;</button>
      </div>
      <div style="text-align: center;">
        <img id="previewImage" src="" alt="Bukti Transfer" class="preview-full-img">
      </div>
    </div>
  </div>

  <script>
    /* MODAL EDIT */
    function openEditModal(id, nama, email, telepon) {
      document.getElementById('edit_id').value = id;
      document.getElementById('edit_nama').value = nama;
      document.getElementById('edit_email').value = email;
      document.getElementById('edit_telepon').value = telepon;
      document.getElementById('editParticipantModal').style.display = 'flex';
    }

    function closeEditModal() {
      document.getElementById('editParticipantModal').style.display = 'none';
    }

    /* MODAL PREVIEW BUKTI PEMBAYARAN */
    function previewBukti(imgUrl, nama) {
      document.getElementById('previewImage').src = imgUrl;
      document.getElementById('previewNamaPeserta').innerText = 'Bukti: ' + nama;
      document.getElementById('previewBuktiModal').style.display = 'flex';
    }

    function closePreviewModal() {
      document.getElementById('previewBuktiModal').style.display = 'none';
      document.getElementById('previewImage').src = '';
    }

    window.onclick = function(event) {
      const modalEdit = document.getElementById('editParticipantModal');
      const modalPreview = document.getElementById('previewBuktiModal');
      
      if (event.target === modalEdit) {
        closeEditModal();
      }
      if (event.target === modalPreview) {
        closePreviewModal();
      }
    }

    /* FITUR PENCARIAN */
    function filterParticipants() {
      const input = document.getElementById('searchParticipant').value.toLowerCase();
      const rows = document.querySelectorAll('.participant-row');

      rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(input) ? '' : 'none';
      });
    }

    /* FITUR EXPORT CSV */
    function exportParticipantsToCSV() {
      let csv = ['Kelas,Nama Peserta,Email,No Telepon,Bukti Pembayaran'];
      const cards = document.querySelectorAll('.participant-card');

      cards.forEach(card => {
        const className = card.querySelector('.class-group-title').innerText.trim();
        const rows = card.querySelectorAll('.participant-row');

        rows.forEach(row => {
          const cols = row.querySelectorAll('td');
          if (cols.length >= 5) {
            const nama = cols[1].innerText.trim();
            const email = cols[2].innerText.trim();
            const telepon = cols[3].innerText.trim();
            const img = cols[4].querySelector('img');
            const buktiUrl = img ? img.src : 'Belum Upload';

            csv.push(`"${className}","${nama}","${email}","${telepon}","${buktiUrl}"`);
          }
        });
      });

      if (csv.length <= 1) {
        alert('Tidak ada data peserta untuk diexport.');
        return;
      }

      const csvContent = 'data:text/csv;charset=utf-8,' + csv.join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', 'daftar_peserta_loka_jiwa.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  </script>

</body>
</html>