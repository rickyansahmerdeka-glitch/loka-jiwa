<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - Joglo Yoga</title>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600&family=Plus+Jakarta+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root { --jati-tua: #3D2314; --jati-madu: #A86532; --krem-kayu: #F4EFEA; --merah-bata: #9E4735; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--krem-kayu); color: var(--jati-tua); display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-card { background: #fff; padding: 40px; border-radius: 8px; border: 1px solid #dcd5cc; width: 100%; max-width: 380px; box-shadow: 0 4px 15px rgba(61, 35, 20, 0.08); text-align: center; }
        h2 { font-family: 'Cormorant Garamond', serif; font-size: 32px; margin-bottom: 25px; }
        .error-msg { background-color: #faecea; color: var(--merah-bata); padding: 10px; border-radius: 4px; font-size: 13px; margin-bottom: 20px; }
        input { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; background-color: var(--jati-madu); color: #fff; border: none; padding: 12px; border-radius: 4px; font-size: 15px; cursor: pointer; }
        button:hover { background-color: #8c5328; }
        .back-link { display: block; margin-top: 20px; font-size: 13px; color: var(--jati-tua); text-decoration: none; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Panel Pengelola</h2>
        <?php if($this->session->flashdata('error')): ?>
            <div class="error-msg"><?= $this->session->flashdata('error'); ?></div>
        <?php endif; ?>
        <form action="<?= site_url('auth/proses_login'); ?>" method="post">
            <input type="text" name="username" placeholder="Username Admin" required autocomplete="off">
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Masuk</button>
        </form>
        <a href="<?= site_url('yoga'); ?>" class="back-link">&larr; Beranda Utama</a>
    </div>
</body>
</html>