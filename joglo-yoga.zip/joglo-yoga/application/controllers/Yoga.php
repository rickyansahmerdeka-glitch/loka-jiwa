<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Yoga extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
        $this->load->database();
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
        $this->load->model('Booking_model');
    }

    public function index() {
        $data['schedules'] = $this->Booking_model->get_all_schedules();
        $this->load->view('v_home', $data);
    }

    public function proses_booking() {
        $nama              = $this->input->post('nama', TRUE);
        $email             = $this->input->post('email', TRUE);
        $telepon           = $this->input->post('telepon', TRUE);
        $schedule_id       = $this->input->post('schedule_id', TRUE);
        $metode_pembayaran = $this->input->post('metode_pembayaran', TRUE);

        // --- VALIDASI CEK KUOTA/SISA KURSI ---
        $schedule = $this->db->get_where('schedules', ['id' => $schedule_id])->row();

        if (!$schedule) {
            $this->session->set_flashdata('status', 'gagal');
            $this->session->set_flashdata('error_message', 'Jadwal kelas tidak ditemukan!');
            redirect('yoga#booking');
            return;
        }

        if ($schedule->terisi >= $schedule->kapasitas) {
            $this->session->set_flashdata('status', 'gagal');
            $this->session->set_flashdata('error_message', 'Maaf, kuota untuk kelas ini sudah penuh.');
            redirect('yoga#booking');
            return;
        }

        // --- KONFIGURASI UPLOAD BUKTI PEMBAYARAN ---
        $config['upload_path']   = './uploads/bukti/'; // Lokasi penyimpanan gambar
        $config['allowed_types'] = 'jpg|jpeg|png|webp';
        $config['max_size']      = 2048; // Maksimal ukuran 2MB
        $config['encrypt_name']  = TRUE; // Ubah nama file acak agar tidak ada nama yang bentrok

        // Pastikan folder penyimpanan ada, jika belum buat otomatis
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0777, true);
        }

        $this->load->library('upload', $config);

        $bukti_pembayaran = null;

        // Proses unggah jika customer mengunggah file
        if (!empty($_FILES['bukti_pembayaran']['name'])) {
            if ($this->upload->do_upload('bukti_pembayaran')) {
                $upload_data = $this->upload->data();
                $bukti_pembayaran = $upload_data['file_name'];
            } else {
                // Jika gagal upload, kirim notifikasi error ke flashdata
                $this->session->set_flashdata('status', 'gagal');
                $this->session->set_flashdata('error_message', $this->upload->display_errors('', ''));
                redirect('yoga#booking');
                return;
            }
        }

        // 1. Simpan Data Customer
        $data_customer = [
            'nama'    => $nama,
            'email'   => $email,
            'telepon' => $telepon
        ];
        $customer_id = $this->Booking_model->insert_customer($data_customer);

        // 2. Simpan Data Booking (Termasuk Bukti & Metode Pembayaran)
        $data_booking = [
            'customer_id'       => $customer_id,
            'schedule_id'       => $schedule_id,
            'metode_pembayaran' => $metode_pembayaran,
            'bukti_pembayaran'  => $bukti_pembayaran
        ];

        $this->Booking_model->insert_booking($data_booking);
        $this->Booking_model->update_slots($schedule_id);

        // 3. Simpan data pendaftaran ke session flashdata untuk ditampilkan di v_home
        $this->session->set_flashdata('pendaftaran_baru', [
            'nama'              => $nama,
            'email'             => $email,
            'telepon'           => $telepon,
            'nama_kelas'        => $schedule->nama_kelas,
            'hari_tanggal'      => $schedule->hari_tanggal,
            'metode_pembayaran' => $metode_pembayaran
        ]);

        $this->session->set_flashdata('status', 'sukses');

        redirect('yoga#booking');
    }
}