<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Booking_model');

        // Proteksi: Wajib login
        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
    }

    public function index() {
        $data['schedules'] = $this->Booking_model->get_all_schedules();
        $data['bookings']  = $this->Booking_model->get_all_bookings();

        $this->load->view('v_admin', $data);
    }

    /* --- FITUR KELOLA JADWAL KELAS --- */

    public function simpan_jadwal()
    {
        $raw_date = $this->input->post('hari_tanggal', TRUE);
        
        // Format tanggal dari datetime-local HTML ('2026-09-27T15:52') ke format standar MySQL ('2026-09-27 15:52:00')
        $formatted_date = !empty($raw_date) ? date('Y-m-d H:i:s', strtotime($raw_date)) : NULL;

        $data = [
            'nama_kelas'   => $this->input->post('nama_kelas', TRUE),
            'instruktur'   => $this->input->post('instruktur', TRUE), // Membaca teks nama instruktur secara langsung
            'hari_tanggal' => $formatted_date,
            'kapasitas'    => $this->input->post('kapasitas', TRUE),
            'terisi'       => 0
        ];

        $this->db->insert('schedules', $data);
        $this->session->set_flashdata('success', 'Jadwal kelas berhasil ditambahkan!');
        redirect('admin');
    }

    public function edit_jadwal($id) {
        $data['schedule'] = $this->Booking_model->get_schedule_by_id($id);
        
        if (empty($data['schedule'])) {
            redirect('admin');
        }

        $this->load->view('v_admin_edit', $data);
    }

    public function update_jadwal($id) {
        $raw_date = $this->input->post('hari_tanggal', TRUE);
        $formatted_date = !empty($raw_date) ? date('Y-m-d H:i:s', strtotime($raw_date)) : NULL;

        $data = [
            'nama_kelas'   => $this->input->post('nama_kelas', TRUE),
            'instruktur'   => $this->input->post('instruktur', TRUE), // Membaca teks nama instruktur secara langsung
            'hari_tanggal' => $formatted_date,
            'kapasitas'    => $this->input->post('kapasitas', TRUE)
        ];

        $this->Booking_model->update_schedule($id, $data);
        $this->session->set_flashdata('success', 'Jadwal kelas berhasil diperbarui!');
        redirect('admin');
    }

    public function hapus_jadwal($id) {
        if (!empty($id)) {
            $this->Booking_model->delete_schedule($id);
            $this->session->set_flashdata('success', 'Jadwal kelas berhasil dihapus!');
        }
        redirect('admin');
    }

    /* --- FITUR KELOLA PESERTA / BOOKING --- */

    public function update_booking() {
        $booking_id = $this->input->post('id', TRUE);
        
        $data = [
            'nama'    => $this->input->post('nama', TRUE),
            'email'   => $this->input->post('email', TRUE),
            'telepon' => $this->input->post('telepon', TRUE)
        ];

        if (!empty($booking_id)) {
            $this->Booking_model->update_booking($booking_id, $data);
            $this->session->set_flashdata('success', 'Data peserta berhasil diperbarui!');
        }

        redirect('admin');
    }

    public function hapus_booking($booking_id, $schedule_id = NULL) {
        if (!empty($booking_id)) {
            $this->Booking_model->delete_booking($booking_id, $schedule_id);
            $this->session->set_flashdata('success', 'Data peserta berhasil dihapus!');
        }
        redirect('admin');
    }
}