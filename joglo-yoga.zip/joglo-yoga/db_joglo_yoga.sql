-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2026 at 02:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_joglo_yoga`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `nama_lengkap`, `created_at`) VALUES
(2, 'admin', 'c289ffe12a30c94530b7fc4e532e2f42', '', '2026-09-26 19:15:29'),
(5, 'keysa', '4edcdca0869baf1d4e677eb57f7e60eb', '', '2026-10-02 12:24:32'),
(6, 'keysa', '4edcdca0869baf1d4e677eb57f7e60eb', '', '2026-10-02 12:24:45');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `tanggal_booking` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `customer_id`, `schedule_id`, `metode_pembayaran`, `bukti_pembayaran`, `tanggal_booking`) VALUES
(17, 19, 16, 'qris', '1297f58dbbda8cbbfb253288be391f53.png', '2026-10-02 12:15:41');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `nama`, `email`, `telepon`, `created_at`) VALUES
(1, 'ricky', 'ricky@gmail.com', '089655286835', '2026-09-26 19:03:25'),
(2, 'rez', 'REZA@GMAIL.COM', '089238492', '2026-09-26 19:03:48'),
(3, 'RC', 'RDB@GMAIL.COM', '983492', '2026-09-26 19:05:37'),
(4, 'keysaFGDGFDF', 'KEYSA@gmail.com', '089887878', '2026-09-27 01:48:58'),
(5, 'eyry', 'ricky@gmail.com', '0928098234', '2026-09-27 02:15:34'),
(6, 'rez', 'REZA@GMAIL.COM', '089384', '2026-09-27 02:27:54'),
(7, 'afaf', 'fa@gmail.com', '685865', '2026-09-27 02:56:38'),
(8, 'erwer', 'keysa@gmail.com', '0842384', '2026-09-27 03:33:02'),
(9, 'kaaaaaaa', 'gaga@gmail.com', '08908080', '2026-09-27 03:35:21'),
(10, 'dfsf', 'sdfsdf@gmail.com', '90834985', '2026-09-27 03:41:33'),
(11, 'keyaaaaaaaa', 'keysaaa@gmail.com', '087878979878', '2026-09-27 07:57:43'),
(12, 'erwrwer`', 'fds@gmail.com', '0784578345', '2026-09-27 08:12:54'),
(13, 'ricky', 'ricky@gmail.com', '09874578888', '2026-09-27 08:18:41'),
(14, 'TERTET', 'WERWER@GMAIL.COM', '078357', '2026-09-27 08:58:29'),
(15, 'rr', 'rrye@gmail.com', '09834590839', '2026-10-02 10:30:55'),
(16, 'rictty', 'hduh@gmail.com', '089655286835', '2026-10-02 10:40:56'),
(17, 'ricky`', 'riqru@gmail.co', '089655286835', '2026-10-02 10:46:29'),
(18, 'Keysa', 'Keysa@gmail.com', '089655286835', '2026-10-02 12:12:22'),
(19, 'Keysaa', 'Keysa@gmail.com', '089655286835', '2026-10-02 12:15:41');

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `id` int(11) NOT NULL,
  `nama_instruktur` varchar(100) NOT NULL,
  `spesialisasi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`id`, `nama_instruktur`, `spesialisasi`) VALUES
(1, 'Ratih', 'Hatha & Tradisional'),
(2, 'Dimas', 'Vinyasa Flow');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `nama_kelas` varchar(100) NOT NULL,
  `instruktur` varchar(100) DEFAULT NULL,
  `hari_tanggal` datetime NOT NULL,
  `kapasitas` int(11) NOT NULL,
  `terisi` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `nama_kelas`, `instruktur`, `hari_tanggal`, `kapasitas`, `terisi`) VALUES
(16, 'Beginner', 'Ricky (Yoga Rilex)', '2026-10-02 19:11:00', 5, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `schedule_id` (`schedule_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `instructor_id` (`instruktur`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
